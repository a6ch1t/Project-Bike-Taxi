from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from app1.models import *
from .form import *

# Create your views here.

from .models import *
from app1.form import *

def index(request):
    return render(request,'index.html')

def service(request):
    return render(request,'service.html')

def about(request):
    return render(request,'about.html')

def feedback(request):
    f=Feedback.objects.all()
    return render(request,'feedback.html',{'feedback':f})

def contact(request):
    if request.method== 'POST':
        name=request.POST.get('name')
        phone=request.POST.get('phone')
        email=request.POST.get('email')
        message=request.POST.get('message')
        feedback = Feedback.objects.create(name=name,phone=phone,email=email,message=message)
        feedback.save()
    return render(request,'contact.html')




def signup(request):
    if request.method== 'POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        password1=request.POST.get('pass1')
        password2=request.POST.get('pass2')
        if password1==password2:
            if User.objects.filter(username=username,email=email).exists():
                messages.info(request,'useername already exists!')
                print("Already Have")
                return redirect(signup)
            else:
                new_user=User.objects.create_user(username,email,password1)
                new_user.save()
                return redirect(user_login)
        else:
            print("wrong Password")
    return render(request,'signup.html')
    

def user_login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password1=request.POST.get('pass1')
        user=authenticate(request,username=username,password=password1)
        if user is not None:
            login(request,user)
            return redirect(index)
        else:
            messages.info(request,'user not exist')
            print('user not exist')
            return redirect(user_login)
    return render(request,'login.html')


def user_logout(request):
    logout(request)
    return redirect(user_login)

def cart(request):
    e=Wehicle.objects.filter(cato=1)
    f=Wehicle.objects.filter(cato=2)
    return render(request,'cart.html',{'EV':e, 'FV':f})

def checkoute(request,p):
    a=Wehicle.objects.get(id=p)
    l=Locate.objects.all()
    if request.method=='POST':
        starting=request.POST.get('start')
        reaching=request.POST.get('ends')
        a1=Locate.objects.get(location=starting)
        b=a1.id
        a2=Locate.objects.get(location=reaching)
        b2=a2.id
        q='EV'
        w='FV'
        c=a.cato.name
        print(c)
        if c==w:
            if b < b2:
                c=b2-b
                charge=c*15
                rydinfo= Rydeinfo.objects.create(starting_location=starting, ending_location=reaching, wehicle=a, price=charge, user=request.user)
                rydinfo.save()
                return redirect(confirm)
            elif b2 < b:
                c=b-b2
                charge=c*15
                rydinfo= Rydeinfo.objects.create(starting_location=starting, ending_location=reaching, wehicle=a, price=charge, user=request.user)
                rydinfo.save()
                return redirect(confirm)
            else:
                return redirect(checkoute)
        elif c==q:
            if b < b2:
                c=b2-b
                charge=c*17
                rydinfo= Rydeinfo.objects.create(starting_location=starting, ending_location=reaching, wehicle=a, price=charge, user=request.user)
                rydinfo.save()
                return redirect(confirm)
            elif b2 < b:
                c=b-b2
                charge=c*17
                rydinfo= Rydeinfo.objects.create(starting_location=starting, ending_location=reaching, wehicle=a, price=charge, user=request.user)
                rydinfo.save()
                return redirect(confirm)
            else:
                return redirect(checkoute)
        else:
            return redirect(cart)
        
    return render(request,'forme.html',{'locate':l,'w':a})

def confirm(request):
    inf = Rydeinfo.objects.filter(user = request.user).order_by('-id').first()
    return render(request,'confirm.html',{'information':inf})

def deleride(request,d):
    a = Rydeinfo.objects.get(id=d)
    a.delete()
    return redirect(cart)
def byke(request):
    inf = Rydeinfo.objects.filter(user = request.user).order_by('-id').first()
    return render(request,'successful.html',{'information':inf})

def history(request):
    l = Rydeinfo.objects.filter(user = request.user)
    return render (request,'history.html',{'information':l})