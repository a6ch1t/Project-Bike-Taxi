from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Locate)
admin.site.register(Rydeinfo)
admin.site.register(cat)
admin.site.register(Wehicle)